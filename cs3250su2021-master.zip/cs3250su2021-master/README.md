# CS3250 Cyber Physical Systems 2021 Summer -- cs3250su2021
----------------
This repo is for Cyber Physical System Class: cs3250su2021

### Class Instructor:
Professor Gurminder Singh

### Lab Instructor:
Charles Prince

# Cyber Physical Systems Lab
----------------

## Summary:

This location will be used to store most of the material for the class.  In the past
Sakai PDF would have some characters missing when using cut-and-paste most noteably 
the '\_' characters would be removed. Additionally the cle site, due to the graphical
nature of cle, the and the PIs limited resources, cle would take a while to download.
This location allows for a quick and easy way to download code and instructional material 
for the Raspberry PI's.

## GIT started
----------------

### Windows: 

If you are using a version that does not support native git commands from the command line, search google.com for "git bash download"

downlaod git bash mingwin 

start the git-bash conslole. 

OR 

You can also use putty 

## All users: Windows, Mac, Linux


### Command line instructions
----------------

You can also upload existing files from your computer using the instructions below.

### Create a new file

mkdir ~/git/

cd ~/git

git clone git@gitlab.nps.edu:cs/cs3250su2021.git

OR

git clone https://gitlab.nps.edu/cs/cs3250su2021/

cd cs3250su2021

vi file

git add file

git commit -m "add file" file

git push 

## You can also use git without a password -- using public key ssh:
----------------

ssh-keygen   (windows/git/bash: ssh-keygen.exe)

ssh-keygen -t rsa -C "your.email@example.com" -b 4096

see: https://gitlab.nps.edu/help/ssh/README

<no password>

save as: id_rsa <default>

should provide you two keys: id_rsa, id_rsa.pub

cat id_rsa.pub and copy/paste it to:

### ... Then do one of the following 3 things:

### 1. Owners of the Repo do:

ToolBar LeftHandSideOfMain web page bottom button 'Settings', for repo page click --'Repository' Button

click on: radio box Titled:"Write access allowed" -- in order to push to master

paste pub key into the ssh key window (you may have to wait up to 5min to use the key)

### 2. students do:

Go to top right of https://gitlab.nps.edu/ user screen, click on the user symbol (top far left), then click on the drop down list item

"Settings", then click on the far left toolbar button "SSH Keys"

paste pub key into the ssh key window (you may have to wait up to 5min to use the key)


## Git global setup (modify accordingly)
----------------

git config --global user.name "Prince, Charles D"

git config --global user.email "cdprince@nps.edu"
