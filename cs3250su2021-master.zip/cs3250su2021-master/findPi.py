#!/usr/bin/python3
#!/usr/bin/python3                                                  #pi
#!/Library/Frameworks/Python.framework/Versions/3.9/bin/python3     #macosx
import os
import sys
#import subprocess
from subprocess import PIPE, Popen
import optparse

a=[]
bg=2
ed=255
pos="pi"
pn="10.0.0."
proc=None
## findPI.py <inQuotesIPV4NetworkFirst3Quads+.> <begRange> <endRange>
##[ argv[1]== beginning range ]
##[ argv[2]== end range ]
#if( len(sys.argv) > 4 or len(sys.argv) == 2):
#   print("Error: too many arguments")
#   os._exit(0)
#if(len(sys.argv) == 4):
#   pn=sys.argv[1]
#   bg=sys.argv[2]
#   ed=sys.argv[3]

def main():
   try: 
      ibg=int(bg)
      ied=int(ed)
   except ValueError:
      print("Error: beginning and ending values are not integer values, they must be.")
      os._exit(0)
   if(pos=="pi"):
       print("ping -w 1 IP") #pi
   elif(pos=="macos"):
       print("ping -c 1 IP")  #macosx
   else:
       print("DEBUG: pos not found")
   out=""
   for p in range(ibg,ied+1):
       #pn="10.0.0."
       #subprocess.call(["echo", "-w", "1", "ping", pn+str(p) ])
       #with open("./a.txt", 'a') as fout:
       #    fout.write(pn+str(p))
       #    subprocess.call(["ping", "-w", "1", pn+str(p)], stdout=fout)
       #    fout.close()
       ip=pn+str(p)
       m="ip="+str(ip)
       if(pos=="pi"):
           proc=Popen(["ping", "-w", "1", ip], stdout=PIPE, stderr=PIPE)  #pi uses -w 1
       elif(pos=="macos"):
           proc=Popen(["ping", "-W", "2", "-i", "0.8", "-c", "1", ip], stdout=PIPE, stderr=PIPE)   #macosx uses -c 1
       else:
           print("DEBUG: pos not found")
       stdout, stderr = proc.communicate()
       #print('standard out='+str(stdout))
       #standard out=b'PING 10.0.0.1 (10.0.0.1): 56 data bytes\n64 bytes from 10.0.0.1: icmp_seq=0 ttl=64 time=1.955 ms\n\n--- 10.0.0.1 ping statistics ---\n
       #  1 packets transmitted, 1 packets received, 0.0% packet loss\nround-trip min/avg/max/stddev = 1.955/1.955/1.955/0.000 ms\n'
       #  pn=10.0.0. p=2 ip=10.0.0.2
       #  standard out=b'PING 10.0.0.2 (10.0.0.2): 56 data bytes\n\n--- 10.0.0.2 ping statistics ---\n1 packets transmitted, 0 packets received, 100.0% packet loss\n'
       #if( b'rtt' in stdout):
       #    a.append(pn+str(p))
       if( b'ttl' in stdout):
           a.append(pn+str(p))
           print(m+" -- found")
       else:
           print(m)
   print("found: "+str(a))

if(__name__ == "__main__"):
    # findPI.py <inQuotesIPV4NetworkFirst3Quads+.> <begRange> <endRange>
    progN=sys.argv[0]
    usage = "usage: "+progN+" -n <inQuotesIPV4NetworkFirst3Quads+.> -b <begRange> -e <endRange> [-o <macos|pi>]"
    example = "example: "+progN+" -n \'10.0.0.\' -b 2 -e 255"
    parser = optparse.OptionParser(usage=usage, version="%prog 1.0")
    parser.add_option("-n", "--network",
          action='store',
          type="string",
          dest="pn",
          default='10.0.0.',
          help="IPV4 network Quad A first 3 Quads and a . at the end")
    parser.add_option("-b", "--beg",
          type="int",
          action="store",
          dest="bg",
          default=2,
          help="Beginning range to try pinging from")
    parser.add_option("-e", "--end",
          type="int",
          action="store",
          dest="ed",
          default=255,
          help="End range to try pinging from")
    parser.add_option("-o", "--os",
          type="string",
          action="store",
          dest="pos",
          default="pi",
          help="input your os, either: \"macos\", or \"pi\"")
    (options, args) = parser.parse_args()
    pn=options.pn
    bg=options.bg
    ed=options.ed
    pos=options.pos
    if( len(sys.argv) > 9 or len(sys.argv) < 7):
       print("number of arguments = "+str(len(sys.argv)))
       print("Error: wrong number of arguments, there should be 7 arguments")
       print(usage); print(example)
       os._exit(0)
    try:
        main()
    except KeyboardInterrupt:
        print("exiting program...")
os._exit(1)

